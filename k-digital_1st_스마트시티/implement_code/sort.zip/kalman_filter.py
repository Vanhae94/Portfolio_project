import numpy as np

class KalmanFilter:
    def __init__(self):
        # Initialize variables
        self.dt = 1.0  # time interval
        self.u = 0.0  # acceleration magnitude
        self.x = np.matrix([[0.], [0.], [0.], [0.]])  # initial state (location and velocity)
        self.A = np.matrix([[1., 0., self.dt, 0.],
                            [0., 1., 0., self.dt],
                            [0., 0., 1., 0.],
                            [0., 0., 0., 1.]])  # state transition matrix
        self.B = np.matrix([[0.5 * self.dt**2],
                            [0.5 * self.dt**2],
                            [self.dt],
                            [self.dt]])  # control input matrix
        self.H = np.matrix([[1., 0., 0., 0.],
                            [0., 1., 0., 0.]])  # measurement mapping matrix
        self.P = np.eye(self.A.shape[1])  # initial covariance matrix
        self.Q = np.eye(self.A.shape[1])  # process noise covariance
        self.R = np.eye(self.H.shape[0])  # measurement noise covariance
        self.lastResult = np.matrix([[0.], [0.]])

    def predict(self):
        # Predict state and covariance
        self.x = np.dot(self.A, self.x) + np.dot(self.B, self.u)
        self.P = np.dot(np.dot(self.A, self.P), self.A.T) + self.Q
        self.lastResult = self.x
        return self.x

    def correct(self, z):
        # Kalman Gain
        S = np.dot(self.H, np.dot(self.P, self.H.T)) + self.R
        K = np.dot(np.dot(self.P, self.H.T), np.linalg.inv(S))

        # Update state and covariance
        y = z - np.dot(self.H, self.x)  # measurement residual
        self.x = self.x + np.dot(K, y)
        I = np.eye(self.H.shape[1])
        self.P = (I - np.dot(K, self.H)) * self.P
        self.lastResult = self.x
        return self.x